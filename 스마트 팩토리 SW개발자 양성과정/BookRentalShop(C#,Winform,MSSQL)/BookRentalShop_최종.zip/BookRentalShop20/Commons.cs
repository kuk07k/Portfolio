﻿//Commons
namespace BookRentalShop20
{
    public static class Commons
    {
        //공용 연결 문자열
        public static string CONNSTRING =
            "Data Source=172.30.1.31;Initial Catalog=sqlDB;Persist Security Info=True;User ID=sa;Password=tjehddn123";

        public static string LOGINUSERID = "";
    }
}
