﻿namespace SF_MiniProject
{
    partial class 제작자
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(제작자));
            this.동우 = new MetroFramework.Controls.MetroLabel();
            this.용혁 = new MetroFramework.Controls.MetroLabel();
            this.혜진 = new MetroFramework.Controls.MetroLabel();
            this.지윤 = new MetroFramework.Controls.MetroLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // 동우
            // 
            this.동우.AutoSize = true;
            this.동우.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.동우.Location = new System.Drawing.Point(71, 390);
            this.동우.Name = "동우";
            this.동우.Size = new System.Drawing.Size(138, 25);
            this.동우.TabIndex = 4;
            this.동우.Text = "Seo Dong-Woo";
            // 
            // 용혁
            // 
            this.용혁.AutoSize = true;
            this.용혁.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.용혁.Location = new System.Drawing.Point(327, 390);
            this.용혁.Name = "용혁";
            this.용혁.Size = new System.Drawing.Size(146, 25);
            this.용혁.TabIndex = 5;
            this.용혁.Text = "Bang Yong-Hyuk";
            // 
            // 혜진
            // 
            this.혜진.AutoSize = true;
            this.혜진.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.혜진.Location = new System.Drawing.Point(610, 390);
            this.혜진.Name = "혜진";
            this.혜진.Size = new System.Drawing.Size(93, 25);
            this.혜진.TabIndex = 6;
            this.혜진.Text = "Yu Hye-jin";
            // 
            // 지윤
            // 
            this.지윤.AutoSize = true;
            this.지윤.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.지윤.Location = new System.Drawing.Point(870, 390);
            this.지윤.Name = "지윤";
            this.지윤.Size = new System.Drawing.Size(95, 25);
            this.지윤.TabIndex = 7;
            this.지윤.Text = "Park Ji-Yun";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(25, 106);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(237, 271);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(282, 106);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(237, 271);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 8;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(539, 106);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(237, 271);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 9;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(799, 106);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(237, 271);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 10;
            this.pictureBox4.TabStop = false;
            // 
            // 제작자
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1060, 466);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.지윤);
            this.Controls.Add(this.혜진);
            this.Controls.Add(this.용혁);
            this.Controls.Add(this.동우);
            this.Controls.Add(this.pictureBox1);
            this.Name = "제작자";
            this.Text = "제작자";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private MetroFramework.Controls.MetroLabel 동우;
        private MetroFramework.Controls.MetroLabel 용혁;
        private MetroFramework.Controls.MetroLabel 혜진;
        private MetroFramework.Controls.MetroLabel 지윤;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
    }
}