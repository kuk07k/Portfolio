﻿namespace SF_MiniProject
{
    partial class 홈페이지
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(홈페이지));
            this.zara = new System.Windows.Forms.LinkLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.pro = new System.Windows.Forms.LinkLabel();
            this.linkLabel4 = new System.Windows.Forms.LinkLabel();
            this.kfq = new System.Windows.Forms.LinkLabel();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.blackyak = new System.Windows.Forms.LinkLabel();
            this.madeby = new System.Windows.Forms.LinkLabel();
            this.konny = new System.Windows.Forms.LinkLabel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.hm = new System.Windows.Forms.LinkLabel();
            this.crocodile = new System.Windows.Forms.LinkLabel();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.osle = new System.Windows.Forms.LinkLabel();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.SuspendLayout();
            // 
            // zara
            // 
            this.zara.AutoSize = true;
            this.zara.BackColor = System.Drawing.Color.White;
            this.zara.Location = new System.Drawing.Point(66, 260);
            this.zara.Name = "zara";
            this.zara.Size = new System.Drawing.Size(86, 15);
            this.zara.TabIndex = 0;
            this.zara.TabStop = true;
            this.zara.Text = "www.zara.kr";
            this.zara.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.zara.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.zara_LinkClicked);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(23, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(181, 41);
            this.label1.TabIndex = 4;
            this.label1.Text = "Partnership";
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(30, 62);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(131, 20);
            this.metroLabel1.TabIndex = 5;
            this.metroLabel1.Text = "주요공식협력사 ▶";
            // 
            // pro
            // 
            this.pro.AutoSize = true;
            this.pro.BackColor = System.Drawing.Color.White;
            this.pro.Font = new System.Drawing.Font("굴림", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.pro.Location = new System.Drawing.Point(522, 500);
            this.pro.Name = "pro";
            this.pro.Size = new System.Drawing.Size(145, 14);
            this.pro.TabIndex = 8;
            this.pro.TabStop = true;
            this.pro.Text = "www.어패럴프로.com";
            this.pro.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.pro.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.pro_LinkClicked);
            // 
            // linkLabel4
            // 
            this.linkLabel4.AutoSize = true;
            this.linkLabel4.BackColor = System.Drawing.Color.White;
            this.linkLabel4.Location = new System.Drawing.Point(45, 384);
            this.linkLabel4.Name = "linkLabel4";
            this.linkLabel4.Size = new System.Drawing.Size(0, 15);
            this.linkLabel4.TabIndex = 10;
            this.linkLabel4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // kfq
            // 
            this.kfq.AutoSize = true;
            this.kfq.BackColor = System.Drawing.Color.White;
            this.kfq.Location = new System.Drawing.Point(295, 384);
            this.kfq.Name = "kfq";
            this.kfq.Size = new System.Drawing.Size(95, 15);
            this.kfq.TabIndex = 12;
            this.kfq.TabStop = true;
            this.kfq.Text = "www.kfq.or.kr";
            this.kfq.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.kfq.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.kfq_LinkClicked);
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(277, 182);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(133, 75);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 17;
            this.pictureBox7.TabStop = false;
            // 
            // blackyak
            // 
            this.blackyak.AutoSize = true;
            this.blackyak.BackColor = System.Drawing.Color.White;
            this.blackyak.Location = new System.Drawing.Point(278, 260);
            this.blackyak.Name = "blackyak";
            this.blackyak.Size = new System.Drawing.Size(132, 15);
            this.blackyak.TabIndex = 16;
            this.blackyak.TabStop = true;
            this.blackyak.Text = "www.blackyak.com";
            this.blackyak.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.blackyak.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.blackyak_LinkClicked);
            // 
            // madeby
            // 
            this.madeby.AutoSize = true;
            this.madeby.BackColor = System.Drawing.Color.White;
            this.madeby.Location = new System.Drawing.Point(534, 384);
            this.madeby.Name = "madeby";
            this.madeby.Size = new System.Drawing.Size(109, 15);
            this.madeby.TabIndex = 18;
            this.madeby.TabStop = true;
            this.madeby.Text = "www.madeby.kr";
            this.madeby.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.madeby.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.madeby_LinkClicked);
            // 
            // konny
            // 
            this.konny.AutoSize = true;
            this.konny.BackColor = System.Drawing.Color.White;
            this.konny.Location = new System.Drawing.Point(67, 384);
            this.konny.Name = "konny";
            this.konny.Size = new System.Drawing.Size(85, 15);
            this.konny.TabIndex = 22;
            this.konny.TabStop = true;
            this.konny.Text = "konny.co.kr";
            this.konny.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.konny.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.konny_LinkClicked);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(44, 182);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(133, 75);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 25;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(44, 306);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(133, 75);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 26;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(277, 306);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(133, 75);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 27;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(523, 422);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(133, 75);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 28;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(523, 306);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(133, 75);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 29;
            this.pictureBox8.TabStop = false;
            // 
            // hm
            // 
            this.hm.AutoSize = true;
            this.hm.BackColor = System.Drawing.Color.White;
            this.hm.Location = new System.Drawing.Point(290, 500);
            this.hm.Name = "hm";
            this.hm.Size = new System.Drawing.Size(108, 15);
            this.hm.TabIndex = 31;
            this.hm.TabStop = true;
            this.hm.Text = "www.spao.com";
            this.hm.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.hm.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.hm_LinkClicked);
            // 
            // crocodile
            // 
            this.crocodile.AutoSize = true;
            this.crocodile.BackColor = System.Drawing.Color.White;
            this.crocodile.Location = new System.Drawing.Point(540, 260);
            this.crocodile.Name = "crocodile";
            this.crocodile.Size = new System.Drawing.Size(91, 15);
            this.crocodile.TabIndex = 33;
            this.crocodile.TabStop = true;
            this.crocodile.Text = "kr.puma.com";
            this.crocodile.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.crocodile.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.crocodile_LinkClicked);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(44, 422);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(133, 75);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 36;
            this.pictureBox6.TabStop = false;
            // 
            // osle
            // 
            this.osle.AutoSize = true;
            this.osle.BackColor = System.Drawing.Color.White;
            this.osle.Location = new System.Drawing.Point(47, 500);
            this.osle.Name = "osle";
            this.osle.Size = new System.Drawing.Size(127, 15);
            this.osle.TabIndex = 35;
            this.osle.TabStop = true;
            this.osle.Text = "www.nbkorea.com";
            this.osle.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.osle.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.osle_LinkClicked);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(277, 422);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(133, 75);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 32;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(523, 182);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(133, 75);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 34;
            this.pictureBox9.TabStop = false;
            // 
            // 홈페이지
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(695, 572);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.osle);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.crocodile);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.hm);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.konny);
            this.Controls.Add(this.madeby);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.blackyak);
            this.Controls.Add(this.kfq);
            this.Controls.Add(this.linkLabel4);
            this.Controls.Add(this.pro);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.zara);
            this.MaximumSize = new System.Drawing.Size(695, 572);
            this.MinimumSize = new System.Drawing.Size(695, 572);
            this.Name = "홈페이지";
            this.ShowInTaskbar = false;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.LinkLabel zara;
        private System.Windows.Forms.Label label1;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private System.Windows.Forms.LinkLabel pro;
        private System.Windows.Forms.LinkLabel linkLabel4;
        private System.Windows.Forms.LinkLabel kfq;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.LinkLabel blackyak;
        private System.Windows.Forms.LinkLabel madeby;
        private System.Windows.Forms.LinkLabel konny;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.LinkLabel hm;
        private System.Windows.Forms.LinkLabel crocodile;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.LinkLabel osle;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox9;
    }
}