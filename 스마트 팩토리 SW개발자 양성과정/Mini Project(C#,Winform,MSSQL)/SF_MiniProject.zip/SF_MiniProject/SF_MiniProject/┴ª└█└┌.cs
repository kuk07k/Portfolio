﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework.Forms;

namespace SF_MiniProject
{
    public partial class 제작자 : MetroForm
    {
        public 제작자()
        {
            InitializeComponent();
        }
    }
}
