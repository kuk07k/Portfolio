﻿namespace SF_MiniProject
{
    public static class Commons
    {
        public static string CONNSTRING =
            "Data Source=192.168.0.3;" +
            " Initial Catalog = ConDB; " +
            " Persist Security Info=True; " +
            " User ID = sa; Password=p@ssw0rd!! ";
        public static string LOGINUSERID = "";

        public static string Date2 = "";
        public static string Date3 = "";
    }
}
