﻿namespace SF_MiniProject
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
            System.Windows.Forms.ToolStripTextBox toolStripTextBox2;
            System.Windows.Forms.ToolStripTextBox toolStripTextBox3;
            System.Windows.Forms.ToolStripTextBox toolStripTextBox4;
            System.Windows.Forms.ToolStripTextBox toolStripTextBox5;
            System.Windows.Forms.ToolStripTextBox 박지윤;
            System.Windows.Forms.ToolStripTextBox toolStripTextBox7;
            System.Windows.Forms.ToolStripTextBox 유혜진;
            System.Windows.Forms.ToolStripTextBox 방용혁;
            System.Windows.Forms.ToolStripTextBox 서동우;
            System.Windows.Forms.ToolStripTextBox toolStripTextBox6;
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.시작 = new System.Windows.Forms.ToolStripMenuItem();
            this.생산의뢰상담 = new System.Windows.Forms.ToolStripMenuItem();
            this.생산의뢰서 = new System.Windows.Forms.ToolStripMenuItem();
            this.자주하는질문 = new System.Windows.Forms.ToolStripMenuItem();
            this.홈페이지 = new System.Windows.Forms.ToolStripMenuItem();
            this.제작자 = new System.Windows.Forms.ToolStripMenuItem();
            this.UserIDLabel = new MetroFramework.Controls.MetroLabel();
            this.UserIDtext = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.종료 = new System.Windows.Forms.ToolStripMenuItem();
            toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            toolStripTextBox2 = new System.Windows.Forms.ToolStripTextBox();
            toolStripTextBox3 = new System.Windows.Forms.ToolStripTextBox();
            toolStripTextBox4 = new System.Windows.Forms.ToolStripTextBox();
            toolStripTextBox5 = new System.Windows.Forms.ToolStripTextBox();
            박지윤 = new System.Windows.Forms.ToolStripTextBox();
            toolStripTextBox7 = new System.Windows.Forms.ToolStripTextBox();
            유혜진 = new System.Windows.Forms.ToolStripTextBox();
            방용혁 = new System.Windows.Forms.ToolStripTextBox();
            서동우 = new System.Windows.Forms.ToolStripTextBox();
            toolStripTextBox6 = new System.Windows.Forms.ToolStripTextBox();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStripTextBox1
            // 
            toolStripTextBox1.BackColor = System.Drawing.Color.White;
            toolStripTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            toolStripTextBox1.CausesValidation = false;
            toolStripTextBox1.Enabled = false;
            toolStripTextBox1.Font = new System.Drawing.Font("맑은 고딕", 9F);
            toolStripTextBox1.ForeColor = System.Drawing.Color.White;
            toolStripTextBox1.HideSelection = false;
            toolStripTextBox1.Name = "toolStripTextBox1";
            toolStripTextBox1.ShortcutsEnabled = false;
            toolStripTextBox1.Size = new System.Drawing.Size(182, 20);
            // 
            // toolStripTextBox2
            // 
            toolStripTextBox2.BackColor = System.Drawing.Color.White;
            toolStripTextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            toolStripTextBox2.CausesValidation = false;
            toolStripTextBox2.Enabled = false;
            toolStripTextBox2.Font = new System.Drawing.Font("맑은 고딕", 9F);
            toolStripTextBox2.ForeColor = System.Drawing.Color.White;
            toolStripTextBox2.HideSelection = false;
            toolStripTextBox2.Name = "toolStripTextBox2";
            toolStripTextBox2.ShortcutsEnabled = false;
            toolStripTextBox2.Size = new System.Drawing.Size(182, 20);
            // 
            // toolStripTextBox3
            // 
            toolStripTextBox3.BackColor = System.Drawing.Color.White;
            toolStripTextBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            toolStripTextBox3.CausesValidation = false;
            toolStripTextBox3.Enabled = false;
            toolStripTextBox3.Font = new System.Drawing.Font("맑은 고딕", 9F);
            toolStripTextBox3.ForeColor = System.Drawing.Color.White;
            toolStripTextBox3.HideSelection = false;
            toolStripTextBox3.Name = "toolStripTextBox3";
            toolStripTextBox3.ShortcutsEnabled = false;
            toolStripTextBox3.Size = new System.Drawing.Size(182, 20);
            // 
            // toolStripTextBox4
            // 
            toolStripTextBox4.BackColor = System.Drawing.Color.White;
            toolStripTextBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            toolStripTextBox4.CausesValidation = false;
            toolStripTextBox4.Enabled = false;
            toolStripTextBox4.Font = new System.Drawing.Font("맑은 고딕", 9F);
            toolStripTextBox4.ForeColor = System.Drawing.Color.White;
            toolStripTextBox4.HideSelection = false;
            toolStripTextBox4.Name = "toolStripTextBox4";
            toolStripTextBox4.ShortcutsEnabled = false;
            toolStripTextBox4.Size = new System.Drawing.Size(182, 20);
            // 
            // toolStripTextBox5
            // 
            toolStripTextBox5.BackColor = System.Drawing.Color.White;
            toolStripTextBox5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            toolStripTextBox5.CausesValidation = false;
            toolStripTextBox5.Enabled = false;
            toolStripTextBox5.Font = new System.Drawing.Font("맑은 고딕", 9F);
            toolStripTextBox5.ForeColor = System.Drawing.Color.White;
            toolStripTextBox5.HideSelection = false;
            toolStripTextBox5.Name = "toolStripTextBox5";
            toolStripTextBox5.ShortcutsEnabled = false;
            toolStripTextBox5.Size = new System.Drawing.Size(182, 20);
            // 
            // 박지윤
            // 
            박지윤.BackColor = System.Drawing.Color.White;
            박지윤.BorderStyle = System.Windows.Forms.BorderStyle.None;
            박지윤.CausesValidation = false;
            박지윤.Enabled = false;
            박지윤.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            박지윤.ForeColor = System.Drawing.Color.White;
            박지윤.HideSelection = false;
            박지윤.Name = "박지윤";
            박지윤.ShortcutsEnabled = false;
            박지윤.Size = new System.Drawing.Size(182, 20);
            박지윤.Text = "박지윤";
            박지윤.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // toolStripTextBox7
            // 
            toolStripTextBox7.BackColor = System.Drawing.Color.White;
            toolStripTextBox7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            toolStripTextBox7.CausesValidation = false;
            toolStripTextBox7.Enabled = false;
            toolStripTextBox7.Font = new System.Drawing.Font("맑은 고딕", 9F);
            toolStripTextBox7.ForeColor = System.Drawing.Color.White;
            toolStripTextBox7.HideSelection = false;
            toolStripTextBox7.Name = "toolStripTextBox7";
            toolStripTextBox7.ShortcutsEnabled = false;
            toolStripTextBox7.Size = new System.Drawing.Size(182, 20);
            // 
            // 유혜진
            // 
            유혜진.BackColor = System.Drawing.Color.White;
            유혜진.BorderStyle = System.Windows.Forms.BorderStyle.None;
            유혜진.CausesValidation = false;
            유혜진.Enabled = false;
            유혜진.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            유혜진.ForeColor = System.Drawing.Color.White;
            유혜진.HideSelection = false;
            유혜진.Name = "유혜진";
            유혜진.ShortcutsEnabled = false;
            유혜진.Size = new System.Drawing.Size(182, 20);
            유혜진.Text = "유혜진";
            유혜진.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // 방용혁
            // 
            방용혁.BackColor = System.Drawing.Color.White;
            방용혁.BorderStyle = System.Windows.Forms.BorderStyle.None;
            방용혁.CausesValidation = false;
            방용혁.Enabled = false;
            방용혁.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            방용혁.ForeColor = System.Drawing.Color.White;
            방용혁.HideSelection = false;
            방용혁.Name = "방용혁";
            방용혁.ShortcutsEnabled = false;
            방용혁.Size = new System.Drawing.Size(182, 20);
            방용혁.Text = "방용혁";
            방용혁.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // 서동우
            // 
            서동우.BackColor = System.Drawing.Color.White;
            서동우.BorderStyle = System.Windows.Forms.BorderStyle.None;
            서동우.CausesValidation = false;
            서동우.Enabled = false;
            서동우.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            서동우.ForeColor = System.Drawing.Color.White;
            서동우.HideSelection = false;
            서동우.Name = "서동우";
            서동우.ShortcutsEnabled = false;
            서동우.Size = new System.Drawing.Size(182, 20);
            서동우.Text = "서동우";
            서동우.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.White;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Left;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.시작,
            toolStripTextBox1,
            this.생산의뢰상담,
            toolStripTextBox2,
            this.생산의뢰서,
            toolStripTextBox3,
            this.자주하는질문,
            toolStripTextBox4,
            this.홈페이지,
            toolStripTextBox5,
            this.제작자,
            toolStripTextBox6,
            this.종료,
            toolStripTextBox7,
            서동우,
            방용혁,
            유혜진,
            박지윤});
            this.menuStrip1.Location = new System.Drawing.Point(20, 60);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.menuStrip1.Size = new System.Drawing.Size(199, 1022);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 시작
            // 
            this.시작.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.시작.Font = new System.Drawing.Font("맑은 고딕", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.시작.ForeColor = System.Drawing.Color.White;
            this.시작.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.시작.Name = "시작";
            this.시작.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.시작.Size = new System.Drawing.Size(184, 36);
            this.시작.Text = "시작";
            this.시작.Click += new System.EventHandler(this.시작_Click);
            // 
            // 생산의뢰상담
            // 
            this.생산의뢰상담.BackColor = System.Drawing.Color.RoyalBlue;
            this.생산의뢰상담.Font = new System.Drawing.Font("맑은 고딕", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.생산의뢰상담.ForeColor = System.Drawing.Color.White;
            this.생산의뢰상담.Name = "생산의뢰상담";
            this.생산의뢰상담.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.생산의뢰상담.Size = new System.Drawing.Size(184, 36);
            this.생산의뢰상담.Text = "생산의뢰상담";
            this.생산의뢰상담.Click += new System.EventHandler(this.생산의뢰상담_Click);
            // 
            // 생산의뢰서
            // 
            this.생산의뢰서.AutoToolTip = true;
            this.생산의뢰서.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.생산의뢰서.Font = new System.Drawing.Font("맑은 고딕", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.생산의뢰서.ForeColor = System.Drawing.Color.White;
            this.생산의뢰서.Name = "생산의뢰서";
            this.생산의뢰서.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.생산의뢰서.Size = new System.Drawing.Size(184, 36);
            this.생산의뢰서.Text = "생산의뢰서";
            this.생산의뢰서.Click += new System.EventHandler(this.생산의뢰서_Click);
            // 
            // 자주하는질문
            // 
            this.자주하는질문.BackColor = System.Drawing.Color.RoyalBlue;
            this.자주하는질문.Font = new System.Drawing.Font("맑은 고딕", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.자주하는질문.ForeColor = System.Drawing.Color.White;
            this.자주하는질문.Name = "자주하는질문";
            this.자주하는질문.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.자주하는질문.Size = new System.Drawing.Size(184, 36);
            this.자주하는질문.Text = "자주하는 질문";
            this.자주하는질문.Click += new System.EventHandler(this.자주하는질문_Click);
            // 
            // 홈페이지
            // 
            this.홈페이지.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.홈페이지.Font = new System.Drawing.Font("맑은 고딕", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.홈페이지.ForeColor = System.Drawing.Color.White;
            this.홈페이지.Name = "홈페이지";
            this.홈페이지.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.홈페이지.Size = new System.Drawing.Size(184, 36);
            this.홈페이지.Text = "홈페이지";
            this.홈페이지.Click += new System.EventHandler(this.홈페이지_Click);
            // 
            // 제작자
            // 
            this.제작자.AutoToolTip = true;
            this.제작자.BackColor = System.Drawing.Color.RoyalBlue;
            this.제작자.Font = new System.Drawing.Font("맑은 고딕", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.제작자.ForeColor = System.Drawing.Color.White;
            this.제작자.Name = "제작자";
            this.제작자.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.제작자.Size = new System.Drawing.Size(184, 36);
            this.제작자.Text = "제작자";
            this.제작자.Click += new System.EventHandler(this.제작자_Click);
            // 
            // UserIDLabel
            // 
            this.UserIDLabel.AutoSize = true;
            this.UserIDLabel.BackColor = System.Drawing.SystemColors.Window;
            this.UserIDLabel.FontSize = MetroFramework.MetroLabelSize.Small;
            this.UserIDLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.UserIDLabel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.UserIDLabel.Location = new System.Drawing.Point(93, 29);
            this.UserIDLabel.Name = "UserIDLabel";
            this.UserIDLabel.Size = new System.Drawing.Size(58, 17);
            this.UserIDLabel.Style = MetroFramework.MetroColorStyle.Black;
            this.UserIDLabel.TabIndex = 2;
            this.UserIDLabel.Text = "사용자 : ";
            // 
            // UserIDtext
            // 
            this.UserIDtext.AutoSize = true;
            this.UserIDtext.BackColor = System.Drawing.SystemColors.Window;
            this.UserIDtext.FontSize = MetroFramework.MetroLabelSize.Small;
            this.UserIDtext.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.UserIDtext.ForeColor = System.Drawing.SystemColors.ControlText;
            this.UserIDtext.Location = new System.Drawing.Point(147, 29);
            this.UserIDtext.Name = "UserIDtext";
            this.UserIDtext.Size = new System.Drawing.Size(20, 17);
            this.UserIDtext.Style = MetroFramework.MetroColorStyle.Black;
            this.UserIDtext.TabIndex = 3;
            this.UserIDtext.Text = "   ";
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel1.Location = new System.Drawing.Point(25, 21);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(62, 25);
            this.metroLabel1.TabIndex = 5;
            this.metroLabel1.Text = "SFMS";
            // 
            // 종료
            // 
            this.종료.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.종료.Font = new System.Drawing.Font("맑은 고딕", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.종료.ForeColor = System.Drawing.Color.White;
            this.종료.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.종료.Name = "종료";
            this.종료.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.종료.Size = new System.Drawing.Size(184, 36);
            this.종료.Text = "종료";
            this.종료.Click += new System.EventHandler(this.종료_Click);
            // 
            // toolStripTextBox6
            // 
            toolStripTextBox6.BackColor = System.Drawing.Color.White;
            toolStripTextBox6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            toolStripTextBox6.CausesValidation = false;
            toolStripTextBox6.Enabled = false;
            toolStripTextBox6.Font = new System.Drawing.Font("맑은 고딕", 9F);
            toolStripTextBox6.ForeColor = System.Drawing.Color.White;
            toolStripTextBox6.HideSelection = false;
            toolStripTextBox6.Name = "toolStripTextBox6";
            toolStripTextBox6.ShortcutsEnabled = false;
            toolStripTextBox6.Size = new System.Drawing.Size(182, 20);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::SF_MiniProject.Properties.Resources._3;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1080, 1102);
            this.ControlBox = false;
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.UserIDtext);
            this.Controls.Add(this.UserIDLabel);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.IsMdiContainer = true;
            this.Name = "MainForm";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.TransparencyKey = System.Drawing.Color.Empty;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Activated += new System.EventHandler(this.MainForm_Activated);
            this.Load += new System.EventHandler(this.MainForm_Load_1);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 시작;
        private System.Windows.Forms.ToolStripMenuItem 생산의뢰상담;
        private System.Windows.Forms.ToolStripMenuItem 생산의뢰서;
        private System.Windows.Forms.ToolStripMenuItem 자주하는질문;
        private System.Windows.Forms.ToolStripMenuItem 홈페이지;
        private System.Windows.Forms.ToolStripMenuItem 제작자;
        private MetroFramework.Controls.MetroLabel UserIDLabel;
        private MetroFramework.Controls.MetroLabel UserIDtext;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private System.Windows.Forms.ToolStripMenuItem 종료;
    }
}